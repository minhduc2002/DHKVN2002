<?php exit;?>{
    "1": {
        "name": "djnhcaokhaokhat",
        "path": "admin",
        "password": "4df0584df9cf93582bfc6ac8856586a5",
        "userID": "1",
        "role": "1",
        "config": {
            "sizeMax": 0,
            "sizeUse": 1024
        },
        "groupInfo": {
            "1": "write"
        },
        "createTime": 1522159928,
        "status": 1,
        "lastLogin": 1522159939,
        "sizeMax": "0"
    }
}