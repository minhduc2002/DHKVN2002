<?php exit;?>{
    "listType": "icon",
    "listSortField": "name",
    "listSortOrder": "up",
    "fileIconSize": "80",
    "animateOpen": "1",
    "soundOpen": "0",
    "theme": "metro",
    "wall": "http:\/\/az619822.vo.msecnd.net\/files\/MajlisAlJinn_1920x1200.jpg",
    "fileRepeat": "replace",
    "recycleOpen": "1",
    "resizeConfig": "{\"filename\":250,\"filetype\":80,\"filesize\":80,\"filetime\":215,\"editorTreeWidth\":200,\"explorerTreeWidth\":200}"
}