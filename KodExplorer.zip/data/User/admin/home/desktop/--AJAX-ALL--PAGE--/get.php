<?php
$data = rawurlencode(file_get_contents($_GET['url']));
echo "data({'value':'$data'})";
?>