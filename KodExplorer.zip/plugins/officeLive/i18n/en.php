<?php
return array(
	"officeLive.meta.name"				=> "Officelive Viewer",
	"officeLive.meta.title"				=> "Officelive Viewer",
	"officeLive.meta.desc"				=> "Officelive Viewer",

	"officeLive.Config.apiServer"		=> "Server Api",
	"officeLive.Config.apiServerDesc"	=> "<br/><br/>The address of the preview server must be accessible by the server where the server can access kods can use third party services, or Microsoft's official interface <br/> (Kod server must be in the external network, and the need for domain name access)
		<div class = 'grayy 8'> https://owa-box.vips100.com/op/view.aspx?src= </div>
		<div class = 'grayy 8'> https://docview.mingdao.com/op/view.aspx?src= </div>
		<div class = 'grayy 8'> https://preview.tita.com/op/view.aspx?src= </div>
		<div class = 'grayy 8'> https://view.officeapps.live.com/op/view.aspx?src= </div>
		Users can build their own; <a href='http://kodcloud.com/office.html' target='_blank'> learn more </a>"
);