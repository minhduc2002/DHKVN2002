	<script type="text/javascript">
		var funcNull = function(){return false;}
		// document.oncopy	= funcNull;
		// document.oncontextmenu = funcNull;
		// document.ondragstart = funcNull;
		if(	!window.datas && 
			$('.excel-tab-title').length == 0){//没有目录
			$('.navbar-inverse').css('opacity',0);
		}
	</script>
	<div class='powerby'>永中DCS</div>
</html>
